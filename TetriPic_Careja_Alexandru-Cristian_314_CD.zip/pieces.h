#ifndef PIECES_H
#define PIECES_H


void gen_O(char **, int, int, int, int);

void gen_I(char **, int, int, int, int);

void gen_S(char **, int, int, int, int);

void gen_Z(char **, int, int, int, int);

void gen_L(char **, int, int, int, int);

void gen_J(char **, int, int, int, int);

void gen_T(char **, int, int, int, int);


#endif
