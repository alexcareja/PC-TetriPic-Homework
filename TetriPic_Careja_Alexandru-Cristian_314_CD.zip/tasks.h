#ifndef TASKS_H
#define TASKS_H


void task1();

void task2();

void task3();

void task4();

void bonus();


#endif
